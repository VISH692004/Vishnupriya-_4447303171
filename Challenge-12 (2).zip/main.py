
#python program to check if year is leap year or not

year=2000

#to get a year(integer)from the user
#year=int(input "Enter a year":))

#devaide by 100 means (century year) ending with 00
#century year devaided by 400 is leap year 
if(year % 400 ==0 ) and (year %100 ==0 ):
  print ("{0}is a leap year". format(year))

#not devide by 100 means not a century year
#year divide by 4 is a leap year 
elif (year % 4==0) and (year % 100!=0):
  print("{0} is a leap year". format (year))

#if not divided by both 400 (century year) and 4 not (century year)
#y